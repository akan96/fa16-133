## Lab Discussions for Stat 133, Fall 2016

This directory contains all the Rmd files for lab discussions.

Run `make` to generate all html files

Run `make clean` to delete html files
